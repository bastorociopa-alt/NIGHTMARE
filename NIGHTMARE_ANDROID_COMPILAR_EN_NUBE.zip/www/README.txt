NIGHTMARE 3D — versión jugable mejorada para móvil y tablet

QUÉ INCLUYE
- Juego 3D real en primera persona mediante Three.js/WebGL.
- Entorno 3D ampliado: habitación, cama, cómoda, espejo, mesita, lámpara, alfombra, ventana con barrotes y cristal agrietado, silla rota, tuberías, libros, botellas, lata, cadenas, telarañas, manchas, escombros, grietas, polvo y pasillo; todos son objetos geométricos 3D, no imágenes planas.
- Criatura procedural 3D con anatomía por capas, costillas, ojos luminosos, dientes, cuernos, dedos con garras, piernas y jirones.
- Puerta articulada que se abre, linterna, iluminación, niebla y sombras.
- Joystick táctil, gesto de arrastre para mirar, botones para correr e interactuar.
- La criatura persigue al jugador; si lo alcanza aparece pantalla de fin y puedes reiniciar.
- Teclado en ordenador: WASD/flechas para moverte, E para interactuar, F para linterna y Shift para correr.

CÓMO JUGAR
1. Descomprime el ZIP.
2. En ordenador, abre una terminal dentro de esta carpeta y ejecuta: python -m http.server 8000
3. En el ordenador visita http://localhost:8000/3d.html
4. Para móvil/tablet en la misma Wi-Fi, visita http://IP-LOCAL-DEL-ORDENADOR:8000/3d.html (sustituye IP-LOCAL-DEL-ORDENADOR por la IP local del ordenador).
5. Pulsa ENTRAR EN LA PESADILLA. Usa el joystick para caminar y arrastra el dedo sobre la escena para mirar. Acércate a la puerta y pulsa INTERACTUAR.

REQUISITOS Y LIMITACIONES HONESTAS
- Requiere navegador moderno con WebGL y conexión a Internet para cargar Three.js desde CDN.
- Es una demo 3D jugable: los objetos del escenario y la criatura están construidos con geometría tridimensional y materiales generados por código. El HUD (botones, objetivos y texto) permanece en 2D a propósito para que sea legible y manejable en pantalla táctil. No es un juego AAA ni usa modelos escaneados/esculturas profesionales.
- La historia, comportamiento del monstruo y eventos están programados; no hay IA generativa conectada ni comunidad online.
- Para calidad de producción serían necesarios modelos 3D artísticos externos, texturas PBR de alta resolución, optimización y pruebas en dispositivos reales.

NIGHTMARE 3D — MUNDOS POR HISTORIA
---------------------------------
Abre 3d.html desde un servidor local (por ejemplo: python -m http.server 8000)
y entra en http://localhost:8000/3d.html. En la pantalla inicial puedes elegir:
- La habitación (terror clásico)
- La chuche de las 3:17 (pueblo 3D de unicornios)
- La estación que no existía (andén y tren NIVARO 3D)
- Wan Tin Who (calle de China, faroles y taxi 3D)
- El piso trece (ascensor 3D con panel de botones)
- La foto que respira (dormitorio, armario y fotografías 3D)
- Kilómetro 0 (carretera nocturna, señales y coche 3D)

Controles: joystick táctil para moverte, arrastra la pantalla para mirar,
🔦 linterna y botón INTERACTUAR para investigar cada historia. El motor Three.js
se carga desde CDN, por lo que se necesita Internet al iniciar el juego.
