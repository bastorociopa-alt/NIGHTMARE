/* Three.js global cargado desde CDN para permitir abrir la demo como página normal. */
const THREE = window.THREE;
if (!THREE) { document.body.innerHTML = '<div style="background:#08080b;color:#fff;min-height:100vh;display:grid;place-items:center;padding:28px;font:16px system-ui;text-align:center"><div><h1 style="color:#e33b49">NIGHTMARE 3D</h1><p>No se pudo cargar el motor 3D. Comprueba tu conexión a Internet y vuelve a cargar esta página.</p></div></div>'; throw new Error('Three.js no disponible'); }

const scene = new THREE.Scene(); scene.background = new THREE.Color(0x07070b); scene.fog = new THREE.FogExp2(0x08080d, 0.055);
const camera = new THREE.PerspectiveCamera(72, innerWidth/innerHeight, 0.08, 90); camera.position.set(0,1.68,2.8); camera.rotation.order='YXZ';
const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:'high-performance'}); renderer.setPixelRatio(Math.min(devicePixelRatio,1.7)); renderer.setSize(innerWidth,innerHeight); renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap; renderer.outputColorSpace=THREE.SRGBColorSpace; renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.08; document.body.prepend(renderer.domElement);
const mat=(color,roughness=.8,metalness=0)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
const plaster=mat(0x29272a), darkWall=mat(0x111116), wood=mat(0x3a2924), woodLight=mat(0x594036), floorMat=mat(0x29201e), trim=mat(0x171416), metal=mat(0x393a40,.35,.75), dirty=mat(0x484347), cloth=mat(0x29262d), pale=mat(0xaaa39b), black=mat(0x08080b), red=mat(0x6d111b,.6), eyeMat=new THREE.MeshStandardMaterial({color:0xff182c,emissive:0x9c0010,emissiveIntensity:3});
scene.add(new THREE.HemisphereLight(0x72758c,0x171013,.38));
const ambient=new THREE.PointLight(0x8c8eaa,3.0,9); ambient.position.set(-2,2.5,1); scene.add(ambient);
const ceilingLamp=new THREE.PointLight(0xffc78b,2.2,7); ceilingLamp.position.set(1.3,2.65,-1.1); scene.add(ceilingLamp);
function box(parent,name,size,pos,material,cast=true,receive=true){const o=new THREE.Mesh(new THREE.BoxGeometry(...size),material);o.name=name;o.position.set(...pos);o.castShadow=cast;o.receiveShadow=receive;parent.add(o);return o}
// Room shell: open front so player can enter and inspect
box(scene,'floor',[8,.18,13],[0,-.12,-1.8],floorMat);
box(scene,'left wall',[.18,3.3,13],[-4,1.5,-1.8],plaster);box(scene,'right wall',[.18,3.3,13],[4,1.5,-1.8],plaster);
box(scene,'back wall',[8,3.3,.2],[0,1.5,4.65],darkWall);box(scene,'ceiling',[8,.18,13],[0,3.15,-1.8],mat(0x17161b));
// floorboards with seams
for(let z=-7.8;z<4.5;z+=.62){box(scene,'floorboard',[7.7,.018,.58],[0,-.018,z],new THREE.MeshStandardMaterial({color:new THREE.Color().setHSL(.055+Math.random()*.018,.15,.105+Math.random()*.045),roughness:.95}));}
for(let x=-3.5;x<=3.5;x+=1.05)for(let z=-7.5;z<4.5;z+=1.24)box(scene,'nail',[.025,.012,.025],[x,-.005,z],metal,false,false);
// skirting and ceiling beams
for(const x of [-3.88,3.88]){box(scene,'skirting',[.12,.2,12.8],[x,.02,-1.8],trim);for(let z=-7;z<4;z+=2.5)box(scene,'wall stain',[.012,.7,.4],[x*0.985,.7,z],dirty,false,false)}
for(let z=-6;z<4;z+=2.4)box(scene,'ceiling beam',[7.8,.13,.16],[0,3.02,z],trim);
// Door frame and hinged door at end of room
const doorFrame=mat(0x171215), doorMat=mat(0x30201e), doorInset=mat(0x211718);
box(scene,'door frame left',[.18,2.55,.3],[-.91,1.24,-5.65],doorFrame);box(scene,'door frame right',[.18,2.55,.3],[.91,1.24,-5.65],doorFrame);box(scene,'door lintel',[2,.2,.3],[0,2.48,-5.65],doorFrame);
const hinge=new THREE.Group(); hinge.position.set(-.82,0,-5.48); scene.add(hinge);
box(hinge,'door slab',[1.62,2.38,.13],[.81,1.19,0],doorMat);box(hinge,'door upper panel',[1.25,.72,.035],[.81,1.72,.082],doorInset);box(hinge,'door lower panel',[1.25,.72,.035],[.81,.7,.082],doorInset);
for(const x of [.28,1.34]){box(hinge,'door stile',[.075,2.2,.04],[x,1.19,.095],woodLight)}for(const y of [.43,1.16,1.95])box(hinge,'door rail',[1.1,.07,.04],[.81,y,.095],woodLight);
const knob=new THREE.Mesh(new THREE.SphereGeometry(.075,16,12),metal);knob.position.set(1.42,1.1,.15);hinge.add(knob);const knobStem=new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,.08,12),metal);knobStem.rotation.x=Math.PI/2;knobStem.position.set(1.42,1.1,.12);hinge.add(knobStem);
for(let y of [.45,1.2,1.95]){box(hinge,'hinge',[.055,.18,.045],[.06,y,.1],metal)}
// corridor behind door
box(scene,'corridor floor',[5,.12,11],[0,-.1,-11.5],mat(0x181619));box(scene,'corridor left',[.15,3,11],[-2.5,1.4,-11.4],darkWall);box(scene,'corridor right',[.15,3,11],[2.5,1.4,-11.4],darkWall);box(scene,'corridor ceiling',[5,.14,11],[0,2.9,-11.4],darkWall);box(scene,'corridor end',[5,3,.15],[0,1.4,-16.9],darkWall);
for(let z=-7;z>-16;z-=2.5){box(scene,'corridor trim',[.07,2.7,.09],[-2.38,1.35,z],wood);box(scene,'corridor trim',[.07,2.7,.09],[2.38,1.35,z],wood)}
const corridorLight=new THREE.PointLight(0x626f91,0,10);corridorLight.position.set(0,2.25,-10);scene.add(corridorLight);
// Bed on left side, blankets and pillow
const bed= new THREE.Group();bed.position.set(-2.45,0,.1);scene.add(bed);box(bed,'bed frame',[2.1,.28,3.1],[0,.35,0],wood);box(bed,'mattress',[2.02,.3,2.98],[0,.58,0],mat(0x666067));box(bed,'blanket',[2.03,.15,1.95],[0,.78,.45],cloth);box(bed,'pillow',[.9,.18,.62],[0,.79,-.95],pale);box(bed,'bed headboard',[2.15,.95,.13],[0,.85,-1.52],woodLight);
// dresser right
const dresser=new THREE.Group();dresser.position.set(2.65,0,-.4);scene.add(dresser);box(dresser,'dresser body',[1.3,1.3,.65],[0,.68,0],wood);for(let y=.3;y<1.2;y+=.38){box(dresser,'drawer',[1.12,.3,.055],[0,y,.34],woodLight);box(dresser,'drawer handle',[.2,.045,.055],[0,y,.39],metal)}box(dresser,'dresser top',[1.45,.1,.78],[0,1.36,0],woodLight);
// mirror with tarnished frame
const mirrorFrame=mat(0x18171a,.45,.25);box(scene,'mirror frame',[1.1,1.55,.12],[2.15,2,-2.25],mirrorFrame);const mirror=new THREE.Mesh(new THREE.PlaneGeometry(.88,1.3),new THREE.MeshStandardMaterial({color:0x343944,metalness:.7,roughness:.25,emissive:0x11131c}));mirror.position.set(2.15,2,-2.17);scene.add(mirror);
// picture frames, crooked art
for(const [x,y,z,rot] of [[-3.88,2,-1.6,.08],[3.88,2,.9,-.1]]){const frame=box(scene,'picture frame',[.12,.85,.65],[x,y,z],woodLight);frame.rotation.z=rot;const art=box(scene,'picture',[.04,.65,.46],[x+(x<0?.07:-.07),y,z],mat(0x17191f));art.rotation.z=rot;}
// Environmental storytelling props: bedside table, broken lamp, scattered papers and debris.
const nightstand=new THREE.Group();nightstand.position.set(-2.35,0,2.05);scene.add(nightstand);
box(nightstand,'nightstand body',[.82,.68,.72],[0,.43,0],wood);box(nightstand,'nightstand top',[.94,.09,.82],[0,.82,0],woodLight);
for(const x of [-.31,.31])for(const z of [-.25,.25])box(nightstand,'nightstand leg',[.09,.48,.09],[x,.22,z],trim);
box(nightstand,'nightstand drawer',[.62,.22,.045],[0,.58,.38],woodLight);const pull=new THREE.Mesh(new THREE.SphereGeometry(.035,10,8),metal);pull.position.set(0,.58,.42);nightstand.add(pull);
// toppled ceramic lamp with a weak, flickering glow
const lamp=new THREE.Group();lamp.position.set(-2.35,.88,2.03);lamp.rotation.z=-.42;scene.add(lamp);
const lampBase=new THREE.Mesh(new THREE.CylinderGeometry(.14,.18,.08,20),metal);lampBase.position.y=.04;lamp.add(lampBase);
const lampStem=new THREE.Mesh(new THREE.CylinderGeometry(.035,.045,.34,12),metal);lampStem.position.y=.23;lamp.add(lampStem);
const shade=new THREE.Mesh(new THREE.CylinderGeometry(.11,.22,.24,18,1,true),mat(0x62504a));shade.position.y=.48;lamp.add(shade);
const lampGlow=new THREE.PointLight(0xffa46c,.75,4);lampGlow.position.set(-2.2,1.3,2);scene.add(lampGlow);
// worn rug with stitched border
const rugMat=mat(0x321f25);box(scene,'worn rug',[2.5,.025,3.1],[-.05,-.005,.8],rugMat,false,true);
for(const x of [-1.22,1.12])box(scene,'rug seam',[.035,.012,2.95],[x,.012,.8],woodLight,false,false);
for(const z of [-.67,2.27])box(scene,'rug seam',[2.35,.012,.035],[-.05,.012,z],woodLight,false,false);
// scattered papers and a torn photograph near the bed
for(let i=0;i<6;i++){const paper=new THREE.Mesh(new THREE.PlaneGeometry(.28+Math.random()*.18,.2+Math.random()*.18),new THREE.MeshStandardMaterial({color:i===4?0x4a292e:0x9b9285,roughness:1,side:THREE.DoubleSide}));paper.rotation.x=-Math.PI/2;paper.rotation.z=Math.random()*Math.PI;paper.position.set(-1.15+Math.random()*1.7,.015,-.2+Math.random()*2.5);scene.add(paper);}
// wall cracks: thin jagged lines that catch the flashlight
const crackMat=mat(0x0c0b0e);
for(const side of [-1,1]){for(let c=0;c<5;c++){const z=-4.4+c*1.65;const points=[];let y=2.55;for(let j=0;j<5;j++){points.push(new THREE.Vector3(side*3.89,y,z+j*.11));y-=.13+Math.random()*.08;}const curve=new THREE.CatmullRomCurve3(points);const crack=new THREE.Mesh(new THREE.TubeGeometry(curve,12,.008,4,false),crackMat);scene.add(crack);}}
// little shards and rubble along the corridor floor
for(let i=0;i<24;i++){const shard=new THREE.Mesh(new THREE.TetrahedronGeometry(.045+Math.random()*.07),i%3?trim:dirty);shard.position.set((Math.random()-.5)*3.7,.02,-7.4-Math.random()*8.5);shard.rotation.set(Math.random(),Math.random(),Math.random());shard.castShadow=true;scene.add(shard)}
// Extra fully volumetric props: broken chair, window, pipes, books, bottles, chains and cobwebs.
const rust=mat(0x33282a,.65,.45), glass= new THREE.MeshStandardMaterial({color:0x283542,metalness:.55,roughness:.18,emissive:0x101923}), leather=mat(0x242025), paperEdge=mat(0x6e6258);
// A cracked, barred window set into the right wall. Every frame bar is real geometry.
const win=new THREE.Group();win.position.set(3.78,2.02,-4.15);win.rotation.y=-Math.PI/2;scene.add(win);
box(win,'window recess',[1.35,1.55,.12],[0,0,0],trim);
box(win,'window glass',[1.12,1.32,.035],[0,0,.075],glass,false,false);
for(const x of [-.61,.61])box(win,'window jamb',[.09,1.52,.13],[x,0,.11],woodLight);
for(const y of [-.71,.71])box(win,'window rail',[1.3,.09,.13],[0,y,.11],woodLight);
box(win,'window crossbar',[1.2,.055,.08],[0,.05,.15],metal);
for(const x of [-.25,.25])box(win,'iron window bar',[.035,1.35,.06],[x,0,.15],rust);
const crackCurve=new THREE.CatmullRomCurve3([new THREE.Vector3(-.2,.52,.102),new THREE.Vector3(-.08,.26,.102),new THREE.Vector3(-.26,.03,.102),new THREE.Vector3(-.12,-.18,.102),new THREE.Vector3(-.33,-.53,.102)]);
win.add(new THREE.Mesh(new THREE.TubeGeometry(crackCurve,18,.009,4,false),mat(0x0b1018)));
// Broken chair tipped beside the dresser, assembled from 3D wood beams.
const chair=new THREE.Group();chair.position.set(2.45,.02,1.4);chair.rotation.set(.18,0,-.24);scene.add(chair);
box(chair,'chair seat',[.78,.12,.72],[0,.55,0],woodLight);
for(const x of [-.31,.31])for(const z of [-.27,.27]){const leg=box(chair,'chair leg',[.075,.58,.075],[x,.28,z],wood);leg.rotation.z=x*.25;}
for(const x of [-.31,.31]){const back=box(chair,'chair back post',[.075,.92,.075],[x,.98,-.3],woodLight);back.rotation.x=-.1;}
box(chair,'chair back rail',[.7,.12,.075],[0,1.35,-.3],woodLight);
box(chair,'broken chair splinter',[.06,.42,.055],[.17,.97,-.3],dirty).rotation.z=.6;
// Exposed corroded pipes run along the ceiling and down a wall.
function pipe(a,b,r,material){const A=new THREE.Vector3(...a),B=new THREE.Vector3(...b),d=B.clone().sub(A);const mesh=new THREE.Mesh(new THREE.CylinderGeometry(r,r,d.length(),10),material);mesh.position.copy(A).add(B).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());mesh.castShadow=true;mesh.receiveShadow=true;scene.add(mesh);return mesh;}
pipe([-3.7,2.72,-7.1],[-3.7,2.72,3.7],.045,rust);pipe([-3.7,2.72,-7.1],[-3.7,1.05,-7.1],.05,rust);pipe([3.72,2.8,-6.8],[3.72,2.8,2.5],.035,metal);
for(let z=-6.5;z<3;z+=2.3){const clamp=new THREE.Mesh(new THREE.TorusGeometry(.055,.012,6,12),metal);clamp.rotation.x=Math.PI/2;clamp.position.set(-3.7,2.72,z);scene.add(clamp);}
// Fallen books with visible page blocks and covers.
for(let i=0;i<4;i++){const book=new THREE.Group();book.position.set(2.25+i*.11,.08,-1.1+i*.16);book.rotation.y=(i*.6);book.rotation.z=(i%2?-.05:.06);scene.add(book);const w=.3+i*.025,h=.055,d=.23;box(book,'book pages',[w*.94,h*.8,d*.94],[0,0,0],paperEdge);box(book,'book cover',[w,h*.18,d],[0,h*.48,0],i%2?red:woodLight);box(book,'book back cover',[w,h*.18,d],[0,-h*.48,0],leather);box(book,'book spine',[.035,h,d],[ -w*.48,0,0],red);}
// Dusty medicine bottles and a fallen tin can on the floor.
for(const [x,z,scale] of [[2.2,-.1,.9],[2.9,-.85,1.15],[-1.25,1.75,.8]]){const bottle=new THREE.Group();bottle.position.set(x,.05,z);bottle.rotation.z=(x>0?.06:-.8);scene.add(bottle);const bottleMat=new THREE.MeshStandardMaterial({color:0x35443e,roughness:.25,metalness:.15,transparent:true,opacity:.82});const body=new THREE.Mesh(new THREE.CylinderGeometry(.07*scale,.09*scale,.25*scale,14),bottleMat);body.position.y=.15*scale;bottle.add(body);const neck=new THREE.Mesh(new THREE.CylinderGeometry(.035*scale,.045*scale,.09*scale,12),bottleMat);neck.position.y=.32*scale;bottle.add(neck);const cork=new THREE.Mesh(new THREE.CylinderGeometry(.032*scale,.032*scale,.045*scale,10),woodLight);cork.position.y=.39*scale;bottle.add(cork);}
const can=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.22,16),metal);can.position.set(-1.55,.1,-2.15);can.rotation.z=1.25;scene.add(can);
// Hanging chains and a ceiling fixture with a gently swaying bulb.
for(const x of [-1.65,1.7]){for(let i=0;i<10;i++){const link=new THREE.Mesh(new THREE.TorusGeometry(.035,.009,5,9),rust);link.position.set(x,2.85-i*.12,-3.4);link.rotation.x=Math.PI/2+(i%2)*.5;scene.add(link);}}
const fixture=new THREE.Group();fixture.position.set(0,2.85,-1.1);scene.add(fixture);
const fixtureCup=new THREE.Mesh(new THREE.CylinderGeometry(.12,.07,.12,14),metal);fixtureCup.position.y=.02;fixture.add(fixtureCup);
const bulb=new THREE.Mesh(new THREE.SphereGeometry(.075,12,10),new THREE.MeshStandardMaterial({color:0xffd9a0,emissive:0xffa94f,emissiveIntensity:1.7,roughness:.25}));bulb.position.y=-.18;fixture.add(bulb);
const bulbGlow=new THREE.PointLight(0xffbd79,.45,4);bulbGlow.position.y=-.2;fixture.add(bulbGlow);
// Real 3D cobweb strands in ceiling corners.
const webMat=new THREE.MeshBasicMaterial({color:0x77727b,transparent:true,opacity:.3});
for(const corner of [[-3.78,2.82,-6.6],[3.78,2.82,2.9]]){const [cx,cy,cz]=corner;for(let i=0;i<5;i++){const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(cx,cy,cz),new THREE.Vector3(cx+(i-2)*.16,cy-.12,cz+.12),new THREE.Vector3(cx+(i-2)*.25,cy-.3,cz+.28)]);scene.add(new THREE.Mesh(new THREE.TubeGeometry(curve,8,.003,3,false),webMat));}}
// Raised splinters, stones and a dark irregular stain add depth to the floor.
for(let i=0;i<18;i++){const shard=new THREE.Mesh(new THREE.TetrahedronGeometry(.025+Math.random()*.055,0),i%2?wood:dirty);shard.position.set((Math.random()-.5)*6,.015,-5+Math.random()*9);shard.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3);scene.add(shard);}
const stain=new THREE.Mesh(new THREE.CircleGeometry(.43,24),new THREE.MeshStandardMaterial({color:0x210b10,roughness:1,transparent:true,opacity:.78}));stain.rotation.x=-Math.PI/2;stain.scale.set(1.3,.72,1);stain.position.set(.8,-.018,-4.2);scene.add(stain);
// dust particles
const dustGeo=new THREE.BufferGeometry(), dustCount=250, dustPos=[];for(let i=0;i<dustCount;i++)dustPos.push((Math.random()-.5)*7,Math.random()*2.8-0.1,-7+Math.random()*12);dustGeo.setAttribute('position',new THREE.Float32BufferAttribute(dustPos,3));const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0x9a9aa6,size:.018,transparent:true,opacity:.45}));scene.add(dust);
// Flashlight attached to camera
const flashlight=new THREE.SpotLight(0xe1e8ff,0,18,Math.PI/7,.48,1.3);flashlight.position.set(0,0,0);flashlight.target.position.set(0,0,-1);camera.add(flashlight);camera.add(flashlight.target);scene.add(camera);
// Procedural creature model: layered anatomy, torn skin/cloak, articulated limbs, claws and face.
const monster=new THREE.Group();monster.position.set(0,0,-10.8);scene.add(monster);
const skin=new THREE.MeshStandardMaterial({color:0x17151a,roughness:.96,metalness:.02});
const skinRaised=new THREE.MeshStandardMaterial({color:0x30262d,roughness:.9});
const wet=new THREE.MeshStandardMaterial({color:0x08090d,roughness:.24,metalness:.12});
const bone=new THREE.MeshStandardMaterial({color:0x8b8077,roughness:.72});
const mouthMat=new THREE.MeshStandardMaterial({color:0x020103,roughness:1});
function ell(parent,geoMat,pos,scale,rot){const m=new THREE.Mesh(new THREE.SphereGeometry(1,20,14),geoMat);m.position.set(...pos);m.scale.set(...scale);if(rot)m.rotation.set(...rot);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function limb(parent,a,b,r1,r2,material,segments=12){const A=new THREE.Vector3(...a),B=new THREE.Vector3(...b),v=B.clone().sub(A);const m=new THREE.Mesh(new THREE.CylinderGeometry(r2,r1,v.length(),segments,1),material);m.position.copy(A).add(B).multiplyScalar(.5);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),v.normalize());m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
// hunched torso and shoulder blades
ell(monster,skin,[0,1.28,0],[.48,.78,.29],[.15,0,-.08]);ell(monster,skinRaised,[0,1.73,-.015],[.56,.28,.31]);
// exposed ribs on the chest, in curved segmented arcs
for(let row=0;row<4;row++){const y=1.42-row*.16;for(const side of [-1,1]){const rib=ell(monster,bone,[side*(.17+row*.018),y,.247],[.22,.045,.045],[0,0,side*-.32]);rib.rotation.y=side*.12;}}
// elongated neck and skull
limb(monster,[0,1.66,0],[0,1.98,.035],.16,.12,skin,14);
ell(monster,skin,[0,2.14,.015],[.29,.37,.25],[.12,0,0]);
ell(monster,skinRaised,[0,2.30,.13],[.22,.14,.18]);
// hollow eye sockets with deep rims and glowing pin eyes
for(const x of [-.125,.125]){ell(monster,wet,[x,2.19,.226],[.085,.095,.035]);const eye=new THREE.Mesh(new THREE.SphereGeometry(.038,16,12),eyeMat);eye.position.set(x,2.19,.259);monster.add(eye);ell(monster,skinRaised,[x,2.285,.23],[.105,.035,.04],[0,0,x<0?-.12:.12]);}
// jaw hangs open, teeth and long lower chin
ell(monster,mouthMat,[0,1.99,.205],[.17,.105,.065]);ell(monster,skin,[0,1.91,.2],[.17,.09,.095]);
for(let i=0;i<7;i++){const x=(i-3)*.043;const tooth=new THREE.Mesh(new THREE.ConeGeometry(.018,.065,6),bone);tooth.position.set(x,2.005,.267);tooth.rotation.x=Math.PI;monster.add(tooth);const lower=new THREE.Mesh(new THREE.ConeGeometry(.014,.05,6),bone);lower.position.set(x,1.96,.275);monster.add(lower)}
// irregular antler-like bone spikes emerging from skull
for(const side of [-1,1]){limb(monster,[side*.17,2.38,0],[side*.28,2.62,-.02],.065,.035,skinRaised,9);limb(monster,[side*.28,2.62,-.02],[side*.36,2.78,.01],.035,.008,bone,8);}
// long asymmetrical arms, elbows, forearms, hands and hooked fingers
const hands=[];
for(const side of [-1,1]){const shoulder=[side*.42,1.66,0],elbow=[side*.62,1.14,.08],wrist=[side*.7,.63,.15],hand=[side*.72,.48,.2];ell(monster,skin,shoulder,[.17,.2,.17]);limb(monster,shoulder,elbow,.14,.105,skin);ell(monster,skinRaised,elbow,[.12,.13,.12]);limb(monster,elbow,wrist,.105,.065,skin);ell(monster,skin,hand,[.105,.14,.08],[.2,0,side*.15]);hands.push({side,hand});for(let f=0;f<4;f++){const spread=(f-1.5)*.045;const start=[hand[0]+spread,hand[1]-.04,hand[2]+.025];const mid=[start[0]+side*.018,start[1]-.12,start[2]+.025];const tip=[mid[0]+side*.025,mid[1]-.075,mid[2]+.025];limb(monster,start,mid,.025,.018,skin,7);limb(monster,mid,tip,.018,.006,bone,7);}limb(monster,[hand[0]-side*.07,hand[1]+.01,hand[2]],[hand[0]-side*.13,hand[1]-.075,hand[2]+.035],.03,.008,bone,7);}
// narrow, uneven legs and long feet
for(const side of [-1,1]){const hip=[side*.22,.82,0],knee=[side*.25,.43,.045],ankle=[side*.29,.12,.02];ell(monster,skin,hip,[.18,.25,.17]);limb(monster,hip,knee,.13,.085,skin);ell(monster,skinRaised,knee,[.095,.1,.1]);limb(monster,knee,ankle,.085,.05,skin);ell(monster,skin,[side*.3,.08,.13],[.105,.07,.22]);for(let t=0;t<3;t++){const x=side*.3+(t-1)*.055;limb(monster,[x,.08,.25],[x,.045,.37],.025,.005,bone,7)}}
// shredded cloak strips hanging off back and shoulders
for(let i=0;i<7;i++){const x=(i-3)*.12;const len=.55+Math.random()*.45;const strip= new THREE.Mesh(new THREE.BoxGeometry(.07,len,.035),i%2?skin:wet);strip.position.set(x,1.08-len*.18,-.22);strip.rotation.z=(Math.random()-.5)*.22;strip.rotation.x=-.08;strip.castShadow=true;monster.add(strip)}
// spines down the back
for(let i=0;i<6;i++){const spike=new THREE.Mesh(new THREE.ConeGeometry(.07,.22,7),skinRaised);spike.position.set(0,1.85-i*.19,-.27);spike.rotation.x=-Math.PI/2;monster.add(spike)}
monster.scale.setScalar(1.08);monster.visible=false;
// STORY WORLDS: each featured story gets its own real Three.js environment.
const originalWorld = scene.children.filter(o => o !== camera && !o.isLight);
const storyWorlds = {};
function worldGroup(id, bg, fogColor, fogDensity=0.025) {
  const g = new THREE.Group(); g.name='story-world-'+id; g.visible=false; scene.add(g); storyWorlds[id]=g;
  g.userData.bg=bg; g.userData.fog=fogColor; g.userData.fogDensity=fogDensity; return g;
}
function wbox(g,name,size,pos,material,rot=[0,0,0]) { const o=box(g,name,size,pos,material); o.rotation.set(...rot); return o; }
function wcyl(g,name,rTop,rBottom,h,pos,material,segments=12,rot=[0,0,0]) { const o=new THREE.Mesh(new THREE.CylinderGeometry(rTop,rBottom,h,segments),material); o.name=name; o.position.set(...pos); o.rotation.set(...rot); o.castShadow=true;o.receiveShadow=true;g.add(o);return o; }
function wsphere(g,name,rad,pos,material,scale=[1,1,1],segments=16) { const o=new THREE.Mesh(new THREE.SphereGeometry(rad,segments,12),material);o.name=name;o.position.set(...pos);o.scale.set(...scale);o.castShadow=true;o.receiveShadow=true;g.add(o);return o; }
const grass=mat(0x253b2b), candyPink=mat(0xff6fae,.35), candyGold=mat(0xffd66b,.3), unicornWhite=mat(0xd7d4dc,.6), unicornMane=mat(0x9c65c9,.5), railMetal=mat(0x292d35,.4,.7), trainRed=mat(0x34262b,.4,.55), trainGlass=new THREE.MeshStandardMaterial({color:0x101a25,metalness:.45,roughness:.2,emissive:0x15212a}), lanternRed=mat(0x8f2025,.5), chinaWall=mat(0x4a3432), taxiYellow=mat(0xc6a13d,.4,.3), ghostMat=new THREE.MeshStandardMaterial({color:0xb9c6ce,roughness:.4,transparent:true,opacity:.58,emissive:0x293d4b,emissiveIntensity:.5});
// Unicorn story: moonlit candy village, modeled cottages, trees and a recognizable 3D unicorn.
{
 const g=worldGroup('unicorn',0x11172b,0x11172b,.018);wbox(g,'meadow',[28,.25,34],[0,-.2,-7],grass);
 const moon=new THREE.Mesh(new THREE.SphereGeometry(2,24,16),mat(0xc7d5ef,.5));moon.position.set(-8,9,-18);g.add(moon);
 for(let i=0;i<8;i++){const x=(i%4-1.5)*4.8,z=-10-Math.floor(i/4)*8;const wall=mat([0x5d496b,0x4e6270,0x76505d,0x58634e][i%4]);wbox(g,'cottage '+i,[2.5,2.1,2.5],[x,1,z],wall);const roof=new THREE.Mesh(new THREE.ConeGeometry(2,1.25,4),mat(0x34243f));roof.position.set(x,2.65,z);roof.rotation.y=Math.PI/4;g.add(roof);wbox(g,'cottage door',[.55,1.1,.08],[x,.55,z+1.3],wood);for(const wx of [x-.7,x+.7]){wbox(g,'glowing window',[.42,.45,.06],[wx,1.35,z+1.31],new THREE.MeshStandardMaterial({color:0xffd18b,emissive:0xffa13c,emissiveIntensity:1.8}));}}
 for(let i=0;i<18;i++){let x=(Math.random()-.5)*24,z=-20+Math.random()*25;wcyl(g,'tree trunk',.13,.2,1.5,[x,.65,z],wood);wsphere(g,'tree crown',.8,[x,1.7,z],mat(0x1d3a2a),[1,1.15,1]);}
 // Unicorn with body, neck, head, four legs, mane and horn.
 const u=new THREE.Group();u.name='3D unicorn Nube';u.position.set(-1,0,-7);g.add(u);wsphere(u,'unicorn body',.65,[0,1.05,0],unicornWhite,[1.45,.72,.68]);wsphere(u,'unicorn rump',.48,[-.65,1.12,0],unicornWhite,[.9,.95,.8]);wcyl(u,'unicorn neck',.23,.34,.95,[.48,1.55,0],unicornWhite,16,[0,0,-.38]);wsphere(u,'unicorn head',.34,[.72,2.02,.03],unicornWhite,[1.15,.9,.82]);for(const x of [-.88,-.35,.28,.58])wcyl(u,'unicorn leg',.075,.11,.65,[x,.42,0],unicornWhite,10,[0,0,x>.2?-.05:.03]);wcyl(u,'golden unicorn horn',.025,.12,.48,[.84,2.43,.02],candyGold,12,[0,0,-.22]);wsphere(u,'violet mane',.23,[.42,2.12,-.17],unicornMane,[1.5,1.25,.7]);for(const x of [-.9,-.7,-.5])wsphere(u,'mane curls',.15,[x,1.45,-.45],unicornMane,[.8,1.4,.8]);wsphere(u,'unicorn eye',.045,[.94,2.1,.28],black,[1,1,0.5]);
 // The forbidden candy sits in front of the cottage; a strange black whistle hangs above it.
 wsphere(g,'forbidden pink candy',.17,[0,.1,-4.2],candyPink,[1,.7,1]);wcyl(g,'candy stick',.025,.025,.38,[0,-.08,-4.2],pale);const whistle=wcyl(g,'floating dark whistle',.045,.045,.48,[0,2.4,-4.2],metal,12,[0,0,Math.PI/2]);wsphere(g,'whistle eye',.055,[.17,2.4,-4.2],eyeMat);
 g.userData.start={x:0,z:2.8,yaw:0};g.userData.objective='Explora el pueblo y acércate a la chuche rosa. No la comas después de anochecer.';g.userData.status='CAPÍTULO · LA CHUCHE DE LAS 3:17';g.userData.interact='candy';
}
// Train story: 3D station platform, tracks, carriage, lit windows, benches and a ghostly passenger.
{
 const g=worldGroup('train',0x080c13,0x080c13,.018);wbox(g,'station platform',[9,.3,32],[0,-.16,-7],mat(0x39373a));wbox(g,'track bed',[5,.22,34],[0,-.35,-8],mat(0x242326));for(const x of [-1.25,1.25])wbox(g,'steel rail',[.12,.14,34],[x,-.19,-8],railMetal);for(let z=7;z>-25;z-=.75)wbox(g,'rail sleeper',[3.5,.12,.24],[0,-.26,z],wood);
 for(const x of [-4.2,4.2]){wcyl(g,'station column',.16,.2,4,[x,2,-6],metal);wbox(g,'station roof beam',[9,.22,.35],[0,4,-6],metal);wbox(g,'station roof',[9,.16,8],[0,4.15,-8],mat(0x171a22));}
 wbox(g,'NIVARO sign',[4,.9,.15],[0,3.15,-5.8],mat(0x11151c));wbox(g,'sign inner',[3.7,.62,.04],[0,3.15,-5.68],mat(0x26333a));
 const train=new THREE.Group();train.name='Nivaro ghost train';train.position.set(0,0,-11);g.add(train);wbox(train,'train lower chassis',[4, .5, 15],[0,.65,0],railMetal);wbox(train,'train body',[4,2.25,15],[0,1.9,0],trainRed);wbox(train,'train roof',[4.1,.22,15.1],[0,3.13,0],metal);
 for(let z=-6.3;z<=6.4;z+=2.1){wbox(train,'train window frame',[.88,1.05,.1],[0,2.15,z],metal);wbox(train,'train window dark glass',[.72,.87,.04],[0,2.15,z+.07],trainGlass);wbox(train,'warm window glow',[.48,.58,.025],[0,2.15,z+.1],new THREE.MeshStandardMaterial({color:0xb9a17a,emissive:0x72512c,emissiveIntensity:.7}));}
 for(const x of [-1.35,1.35])for(const z of [-5,-2,1,4]){const wheel=wcyl(train,'train wheel',.42,.42,.18,[x,.35,z],metal,16,[0,0,Math.PI/2]);}
 for(const z of [-5,0,5]){wbox(g,'platform bench seat',[2,.14,.5],[3,.8,z],wood);for(const x of [2.2,3.7])wbox(g,'bench leg',[.12,.8,.12],[x,.4,z],metal);}
 for(const z of [-2,-10,-18]){wcyl(g,'lamp post',.06,.09,3,[3.5,1.5,z],metal);wsphere(g,'station lamp',.28,[3.5,3.05,z],new THREE.MeshStandardMaterial({color:0xe5d6ac,emissive:0xffd38a,emissiveIntensity:2}));}
 // Ghost child silhouette on the platform.
 const child=new THREE.Group();child.name='ghost girl passenger';child.position.set(-2.1,0,-7);g.add(child);wsphere(child,'girl head',.25,[0,1.55,0],ghostMat);wbox(child,'girl coat',[.58,.95,.34],[0,.88,0],ghostMat);for(const x of [-.16,.16])wcyl(child,'girl leg',.07,.08,.55,[x,.28,0],ghostMat);for(const x of [-.33,.33])wcyl(child,'girl arm',.06,.06,.7,[x,.95,0],ghostMat,10,[0,0,x<0?-.3:.3]);wsphere(child,'girl eyes',.035,[-.09,1.58,.22],eyeMat);wsphere(child,'girl eyes',.035,[.09,1.58,.22],eyeMat);
 g.userData.start={x:0,z:3.5,yaw:0};g.userData.objective='Explora el andén y examina el tren que lleva el nombre NIVARO.';g.userData.status='CAPÍTULO · LA ESTACIÓN QUE NO EXISTÍA';g.userData.interact='train';
}
// China story: rainy dream street with traditional roofs, red lanterns, a 3D taxi and impossible photographs.
{
 const g=worldGroup('china',0x090d14,0x090d14,.021);wbox(g,'wet China street',[20,.25,34],[0,-.18,-8],mat(0x20272c,.3,.45));wbox(g,'road center line',[.12,.025,30],[0,-.03,-8],mat(0x8d8370));
 for(let side of [-1,1])for(let i=0;i<4;i++){const x=side*(5.4+i%2*.35),z=-3-i*6;wbox(g,'old Chinese building',[3.2,4.2,4],[x,2,z],chinaWall);for(let y of [3.9,4.15]){const roof=wbox(g,'curved tiled roof',[4,.18,1.25],[x,y,z],mat(0x202a31),[0,0,side*.05]);wbox(g,'roof ridge',[4.3,.16,.2],[x,y+.15,z],mat(0x7b2428));}for(let y of [1.4,2.7])for(let dx of [-.75,.75])wbox(g,'lit shop window',[.65,.8,.06],[x+dx,y,z+2.04],new THREE.MeshStandardMaterial({color:0xb28c60,emissive:0x6c3d16,emissiveIntensity:.65}));}
 for(let z=-1;z>-24;z-=4)for(let x of [-3.8,3.8]){wcyl(g,'lantern cord',.025,.025,1.4,[x,3.2,z],metal);wsphere(g,'red paper lantern',.27,[x,2.55,z],lanternRed,[.8,1.2,.8]);wcyl(g,'lantern tassel',.025,.025,.25,[x,2.25,z],candyGold);}
 // Taxi with four wheels, windshield, headlights and interior silhouette.
 const taxi=new THREE.Group();taxi.name='China dream taxi';taxi.position.set(1.1,0,-4.8);taxi.rotation.y=-.18;g.add(taxi);wbox(taxi,'taxi chassis',[2.2,.55,4],[0,.62,0],taxiYellow);wbox(taxi,'taxi cabin',[1.7,.85,1.9],[0,1.25,-.25],mat(0x9a853d));wbox(taxi,'taxi windshield',[1.48,.58,.04],[0,1.34,.73],trainGlass);wbox(taxi,'taxi rear glass',[1.4,.55,.04],[0,1.35,-1.18],trainGlass);for(let x of [-1,1])for(let z of [-1.25,1.25])wcyl(taxi,'taxi wheel',.33,.33,.18,[x,.35,z],black,16,[0,0,Math.PI/2]);for(let x of [-.72,.72])wsphere(taxi,'taxi headlight',.12,[x,.73,2.02],new THREE.MeshStandardMaterial({color:0xffe7a6,emissive:0xffc95e,emissiveIntensity:2}));
 const driver=new THREE.Group();driver.position.set(0,0,-4.8);g.add(driver);wsphere(driver,'driver head',.2,[2.0,1.42,-.15],ghostMat);wbox(driver,'driver body',[.42,.75,.3],[2, .92,-.15],mat(0x101216));
 wbox(g,'impossible photo',[.55,.04,.8],[-.5,.04,-1.2],pale);wbox(g,'phone recording',[.18,.04,.32],[-.5,.08,-1.2],black);
 g.userData.start={x:-1.8,z:3.5,yaw:0};g.userData.objective='Acércate al taxi y examina la grabación llamada «Wan Tin Who».';g.userData.status='CAPÍTULO · WAN TIN WHO';g.userData.interact='taxi';
}
// More seed stories also have dedicated 3D worlds: elevator, breathing photo, endless road.
{
 const g=worldGroup('piso13',0x09090d,0x09090d,.022);wbox(g,'elevator floor',[5,.2,14],[0,-.12,-4],mat(0x343238));wbox(g,'elevator left wall',[.15,3.5,14],[-2.5,1.5,-4],mat(0x28262b));wbox(g,'elevator right wall',[.15,3.5,14],[2.5,1.5,-4],mat(0x28262b));wbox(g,'elevator back',[5,3.5,.15],[0,1.5,-10.8],mat(0x19181d));wbox(g,'lift doors left',[1.2,2.6,.12],[-.62,1.3,-10.65],metal);wbox(g,'lift doors right',[1.2,2.6,.12],[.62,1.3,-10.65],metal);for(let y=.4;y<2.5;y+=.42)wbox(g,'door brushed steel',[.04,.025,.08],[0,y,-10.55],pale);wbox(g,'button panel',[.35,1.7,.12],[1.75,1.6,-10.55],black);for(let i=0;i<13;i++){const y=.9+i*.105;wsphere(g,'elevator floor button '+(i+1),.035,[1.75,y,-10.45],i===12?eyeMat:metal,[1,1,.35],10);}wbox(g,'13 button label',[.18,.12,.02],[1.75,2.3,-10.43],red);wbox(g,'ceiling',[5,.12,14],[0,3.2,-4],mat(0x111116));const light=new THREE.PointLight(0xc9d1ff,2,10);light.position.set(0,2.8,-3);g.add(light);g.userData.start={x:0,z:2.5,yaw:0};g.userData.objective='Explora el ascensor. Hay un botón nuevo entre las plantas.';g.userData.status='CAPÍTULO · EL PISO TRECE';g.userData.interact='elevator';
}
{
 const g=worldGroup('fotografia',0x0c0a0b,0x0c0a0b,.025);wbox(g,'photograph room floor',[8,.2,13],[0,-.12,-3],mat(0x30282a));wbox(g,'bedroom wall',[8,3.3,.18],[0,1.5,-9],mat(0x242126));wbox(g,'left bedroom wall',[.18,3.3,13],[-4,1.5,-3],mat(0x302a2c));wbox(g,'right bedroom wall',[.18,3.3,13],[4,1.5,-3],mat(0x302a2c));wbox(g,'bed frame',[2.4,.35,3],[0,.25,-2.5],wood);wbox(g,'bed mattress',[2.3,.22,2.9],[0,.52,-2.5],pale);wbox(g,'dark blanket',[2.32,.16,1.7],[0,.7,-1.9],cloth);const wardrobe=new THREE.Group();wardrobe.position.set(2.25,0,-6.7);g.add(wardrobe);wbox(wardrobe,'wardrobe body',[1.5,2.5,.75],[0,1.25,0],wood);wbox(wardrobe,'wardrobe left door',[.7,2.35,.08],[-.37,1.25,.42],woodLight);wbox(wardrobe,'wardrobe right door',[.7,2.35,.08],[.37,1.25,.42],woodLight);wbox(wardrobe,'black gap inside wardrobe',[.24,1.9,.06],[0,1.25,.47],black);for(let i=0;i<5;i++){const pic=new THREE.Group();pic.position.set(-1.9+i*.78,1.7,-8.82);g.add(pic);wbox(pic,'photo frame',[.58,.72,.06],[0,0,0],metal);wbox(pic,'impossible photo',[.48,.61,.025],[0,0,.045],mat(i===4?0x171019:0x4a4447));if(i===4){wsphere(pic,'figure in photo',.12,[0,.02,.08],ghostMat,[1,1.7,.4]);}}
 const polaroid=new THREE.Group();polaroid.position.set(-.8,.02,-1.0);polaroid.rotation.x=-Math.PI/2;g.add(polaroid);wbox(polaroid,'polaroid paper',[.7,.04,.85],[0,0,0],pale);wbox(polaroid,'polaroid image',[.55,.02,.54],[0,.025,-.08],mat(0x17181e));wsphere(polaroid,'figure inside photo',.11,[0,.06,-.08],ghostMat,[1,1.4,.4]);g.userData.start={x:0,z:3.3,yaw:0};g.userData.objective='Investiga las fotografías. En cada una, la figura está más cerca.';g.userData.status='CAPÍTULO · LA FOTO QUE RESPIRA';g.userData.interact='photo';
}
{
 const g=worldGroup('kilometro0',0x080b10,0x080b10,.012);wbox(g,'endless asphalt',[10,.2,70],[0,-.14,-20],mat(0x24272b,.7,.1));wbox(g,'left road edge',[.13,.04,70],[-4.2,-.02,-20],pale);wbox(g,'right road edge',[.13,.04,70],[4.2,-.02,-20],pale);for(let z=12;z>-55;z-=4)wbox(g,'road center dash',[.12,.035,1.8],[0,-.02,z],mat(0xc4bfae));for(let side of [-1,1])for(let z=6;z>-45;z-=8){wcyl(g,'roadside dead tree trunk',.12,.2,2.3,[side*(5.5+Math.random()),1.1,z],wood);for(let a=-1;a<=1;a++)wcyl(g,'bare branch',.045,.09,1,[side*(5.5+Math.random())+a*.25,1.7,z],wood,8,[0,0,a*.45]);}
 for(let z of [-5,-21,-37]){wbox(g,'kilometer zero sign post',[.12,1.7,.12],[3.6,.85,z],metal);wbox(g,'KILÓMETRO 0 sign',[1.45,.65,.12],[3.6,1.7,z],woodLight);wbox(g,'sign reflective face',[1.25,.42,.035],[3.6,1.7,z+.08],mat(0x1a1a19));}
 const car=new THREE.Group();car.name='stranded car';car.position.set(-1.1,0,1.2);g.add(car);wbox(car,'car chassis',[1.8,.5,3.6],[0,.55,0],mat(0x272e35,.4,.4));wbox(car,'car cabin',[1.45,.72,1.8],[0,1.08,-.2],trainGlass);for(let x of [-.8,.8])for(let z of [-1.1,1.1])wcyl(car,'car wheel',.28,.28,.16,[x,.32,z],black,14,[0,0,Math.PI/2]);for(let x of [-.58,.58])wsphere(car,'car headlight',.1,[x,.63,1.83],new THREE.MeshStandardMaterial({color:0xffe5ad,emissive:0xffd080,emissiveIntensity:1.8}));g.userData.start={x:0,z:4,yaw:0};g.userData.objective='Sigue la carretera y compara el cartel: cada vez cambia.';g.userData.status='CAPÍTULO · KILÓMETRO 0';g.userData.interact='road';
}
function chooseStory(id){
  originalWorld.forEach(o=>o.visible=false);Object.values(storyWorlds).forEach(g=>g.visible=false);
  const g=storyWorlds[id]||storyWorlds.unicorn;g.visible=true;scene.background=new THREE.Color(g.userData.bg);scene.fog=new THREE.FogExp2(g.userData.fog,g.userData.fogDensity);
  camera.position.set(g.userData.start.x,1.68,g.userData.start.z);yaw=g.userData.start.yaw;pitch=0;camera.rotation.set(0,yaw,0);selectedStory=id;gameOver=false;doorOpen=false;monsterActive=false;monster.visible=false;flashOn=false;flashlight.intensity=0;$('light').classList.remove('on');
  objective.textContent=g.userData.objective;status.textContent=g.userData.status;return g;
}
let selectedStory='room';let activeStoryWorld=null;document.querySelectorAll('.story-choice').forEach(b=>b.addEventListener('click',()=>{selectedStory=b.dataset.world;}));
// Controls/state
let started=false,gameOver=false, yaw=0,pitch=0,doorOpen=false,monsterActive=false,flashOn=false,running=false,moveX=0,moveY=0,dragging=false,lastX=0,lastY=0,joyId=null,dragId=null,phase=0;const velocity=new THREE.Vector3();const clock=new THREE.Clock();
const $=id=>document.getElementById(id);const overlay=$('overlay'),hint=$('hint'),objective=$('objective'),status=$('status');
$('start').addEventListener('click',()=>{if(gameOver){gameOver=false;monster.position.set(0,0,-10.8);hinge.rotation.y=0;corridorLight.intensity=0;overlay.querySelector('.kicker').textContent='NIGHTMARE INTERACTIVE';overlay.querySelector('h1').innerHTML='ELIGE TU<br><em>PESADILLA.</em>';overlay.querySelectorAll('p')[0].textContent='Elige una historia y explórala en primera persona dentro de un escenario 3D.';overlay.querySelectorAll('p')[1].textContent='Móvil/tablet: joystick para caminar, arrastra para mirar y toca INTERACTUAR para investigar.';$('start').textContent='ENTRAR EN LA PESADILLA';} if(!selectedStory)selectedStory='room'; if(selectedStory!=='room')activeStoryWorld=chooseStory(selectedStory);else{originalWorld.forEach(o=>o.visible=true);Object.values(storyWorlds).forEach(g=>g.visible=false);scene.background=new THREE.Color(0x07070b);scene.fog=new THREE.FogExp2(0x08080d,0.055);camera.position.set(0,1.68,2.8);yaw=0;pitch=0;objective.textContent='Explora la habitación. La puerta está al fondo.';status.textContent='CAPÍTULO 01 · DESPIERTA';}started=true;overlay.classList.add('hidden');hint.textContent='Explora. Algo no encaja.';hint.style.opacity='1';setTimeout(()=>hint.style.opacity='0',4000);});
$('light').addEventListener('click',()=>{flashOn=!flashOn;flashlight.intensity=flashOn?42:0;$('light').classList.toggle('on',flashOn)});
$('run').addEventListener('pointerdown',e=>{running=true;$('run').classList.add('on');e.preventDefault()});for(const ev of ['pointerup','pointercancel','pointerleave'])$('run').addEventListener(ev,()=>{running=false;$('run').classList.remove('on')});
function doInteract(){if(!started)return;if(selectedStory!=='room'){const g=storyWorlds[selectedStory];const near=camera.position.distanceTo(new THREE.Vector3(0,0,-4.2));hint.style.opacity='1';if(selectedStory==='unicorn'){objective.textContent='La chuche está en el suelo. El silbido vuelve a sonar desde las casas.';status.textContent='3:17 · SILBIDO DETECTADO';hint.textContent='El envoltorio tiene tu nombre escrito al reverso…';const eye=g.children.find(o=>o.name==='whistle eye');if(eye)eye.material=eyeMat;setTimeout(()=>{hint.style.opacity='0'},2400);}else if(selectedStory==='train'){objective.textContent='El tren NIVARO no aparece en ningún horario. La niña te está esperando.';status.textContent='21:47 · SIN DESTINO';hint.textContent='La niña te muestra una fotografía en la que ya has bajado del tren.';setTimeout(()=>{hint.style.opacity='0'},2800);}else if(selectedStory==='china'){objective.textContent='La grabación contiene tu nombre susurrado detrás de la canción.';status.textContent='WAN TIN WHO · ARCHIVO IMPOSIBLE';hint.textContent='El taxi está vacío… pero el asiento del conductor sigue hundido.';setTimeout(()=>{hint.style.opacity='0'},2800);}else if(selectedStory==='piso13'){objective.textContent='El botón trece se ha iluminado. La cámara del ascensor muestra a alguien detrás de ti.';status.textContent='PLANTA 13 · SUBIENDO';hint.textContent='No has pulsado nada, pero el ascensor empieza a moverse.';setTimeout(()=>{hint.style.opacity='0'},2800);}else if(selectedStory==='fotografia'){objective.textContent='La fotografía acaba de cambiar: ahora hay una figura detrás de ti.';status.textContent='FOTOGRAFÍA ACTUALIZADA';hint.textContent='No recuerdas que nadie estuviera ahí cuando tomaste la foto.';setTimeout(()=>{hint.style.opacity='0'},2800);}else if(selectedStory==='kilometro0'){objective.textContent='El cartel muestra tu matrícula. Los faros se han encendido detrás del coche.';status.textContent='DESTINO ALCANZADO';hint.textContent='El GPS dice: «Has llegado». Pero no hay ningún lugar aquí.';setTimeout(()=>{hint.style.opacity='0'},2800);}return;}const d=camera.position.distanceTo(new THREE.Vector3(0,1,-5.4));if(!doorOpen&&d<4.2){doorOpen=true;objective.textContent='La puerta está abierta. Algo te espera en el pasillo.';status.textContent='CAPÍTULO 01 · NO MIRES';hint.style.opacity='1';hint.textContent='La puerta se abre con un gemido…';corridorLight.intensity=3.6;setTimeout(()=>{hint.style.opacity='0';monster.visible=true;monsterActive=true;objective.textContent='¡ALGO TE HA VISTO! Retrocede o corre.';status.textContent='PELIGRO DETECTADO';},2400);return}if(doorOpen&&camera.position.z<-5.7){hint.textContent='El pasillo huele a tierra mojada.';hint.style.opacity='1';setTimeout(()=>hint.style.opacity='0',1800);return}hint.textContent='Acércate a la puerta para interactuar';hint.style.opacity='1';setTimeout(()=>hint.style.opacity='0',1600)}
$('interact').addEventListener('click',doInteract);window.addEventListener('keydown',e=>{if(e.code==='KeyE')doInteract();if(e.code==='KeyF')$('light').click();if(e.code==='ShiftLeft'||e.code==='ShiftRight')running=true;if(e.code==='KeyW'||e.code==='ArrowUp')moveY=1;if(e.code==='KeyS'||e.code==='ArrowDown')moveY=-1;if(e.code==='KeyA'||e.code==='ArrowLeft')moveX=-1;if(e.code==='KeyD'||e.code==='ArrowRight')moveX=1});window.addEventListener('keyup',e=>{if(e.code==='ShiftLeft'||e.code==='ShiftRight')running=false;if(['KeyW','ArrowUp','KeyS','ArrowDown'].includes(e.code))moveY=0;if(['KeyA','ArrowLeft','KeyD','ArrowRight'].includes(e.code))moveX=0});
// Touch joystick for movement
const joy=$('joystick'),stick=$('stick');function setJoy(e){const r=joy.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const len=Math.hypot(dx,dy),max=34;if(len>max){dx=dx/len*max;dy=dy/len*max}stick.style.left=(33+dx)+'px';stick.style.top=(33+dy)+'px';moveX=dx/max;moveY=-dy/max}
joy.addEventListener('pointerdown',e=>{joyId=e.pointerId;joy.setPointerCapture(joyId);setJoy(e);e.preventDefault()});joy.addEventListener('pointermove',e=>{if(e.pointerId===joyId)setJoy(e)});function releaseJoy(e){if(e.pointerId===joyId){joyId=null;moveX=0;moveY=0;stick.style.left='33px';stick.style.top='33px'}}joy.addEventListener('pointerup',releaseJoy);joy.addEventListener('pointercancel',releaseJoy);
// Drag anywhere except UI to look around. Mobile has a full-screen look gesture.
renderer.domElement.addEventListener('pointerdown',e=>{if(!started||e.pointerType==='mouse')return;dragging=true;dragId=e.pointerId;lastX=e.clientX;lastY=e.clientY;renderer.domElement.setPointerCapture(dragId)});renderer.domElement.addEventListener('pointermove',e=>{if(!dragging||e.pointerId!==dragId)return;const dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;yaw-=dx*.0042;pitch-=dy*.0036;pitch=Math.max(-1.15,Math.min(1.15,pitch))});function stopDrag(e){if(e.pointerId===dragId){dragging=false;dragId=null}}renderer.domElement.addEventListener('pointerup',stopDrag);renderer.domElement.addEventListener('pointercancel',stopDrag);
// Desktop mouse look too
let mouseDown=false;renderer.domElement.addEventListener('mousedown',e=>{if(started){mouseDown=true;lastX=e.clientX;lastY=e.clientY}});window.addEventListener('mouseup',()=>mouseDown=false);window.addEventListener('mousemove',e=>{if(mouseDown){yaw-=(e.clientX-lastX)*.003;pitch-=(e.clientY-lastY)*.003;lastX=e.clientX;lastY=e.clientY;pitch=Math.max(-1.15,Math.min(1.15,pitch))}});
function update(dt){if(!started)return;camera.rotation.y=yaw;camera.rotation.x=pitch;const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));const input=new THREE.Vector3();input.addScaledVector(forward,moveY);input.addScaledVector(right,moveX);if(input.lengthSq()>1)input.normalize();const speed=running?3.5:1.9;camera.position.addScaledVector(input,speed*dt);camera.position.x=THREE.MathUtils.clamp(camera.position.x,-3.55,3.55);camera.position.z=THREE.MathUtils.clamp(camera.position.z,-15.9,4.05);camera.position.y=1.68+Math.sin(clock.elapsedTime*(running?13:5))*Math.min(input.length(),1)*.025;
if(selectedStory==='room'&&doorOpen){hinge.rotation.y=THREE.MathUtils.damp(hinge.rotation.y,-1.72,2.1,dt)}if(selectedStory==='room'&&monsterActive&&!gameOver){phase+=dt;const target=new THREE.Vector3(camera.position.x,0,camera.position.z);const toward=target.clone().sub(new THREE.Vector3(monster.position.x,0,monster.position.z));const dist=toward.length();if(dist>1.45){toward.normalize();monster.position.x+=toward.x*dt*(dist<5?1.22:.34);monster.position.z+=toward.z*dt*(dist<5?1.22:.34);}monster.rotation.y=Math.atan2(camera.position.x-monster.position.x,camera.position.z-monster.position.z)+Math.sin(phase*2.1)*.035;monster.position.y=Math.sin(phase*5)*.025;monster.rotation.z=Math.sin(phase*2.8)*.018;if(dist<1.55){gameOver=true;status.textContent='FIN DEL CAPÍTULO';objective.textContent='Te ha encontrado. Vuelve a intentarlo.';overlay.classList.remove('hidden');overlay.querySelector('.kicker').textContent='HAS SIDO ENCONTRADO';overlay.querySelector('h1').innerHTML='LA OSCURIDAD<br><em>TE ATRAPA.</em>';overlay.querySelectorAll('p')[0].textContent='La criatura te alcanzó en el pasillo. Esta vez, no te quedes quieto.';overlay.querySelectorAll('p')[1].textContent='Pulsa para reiniciar y vuelve a intentarlo.';$('start').textContent='VOLVER A JUGAR';}}
// subtle light flicker
if(selectedStory==='room'){ceilingLamp.intensity=2.0+Math.sin(clock.elapsedTime*8)*.12+(Math.random()>.996?-1.1:0);dust.rotation.y+=dt*.012;}else{const g=storyWorlds[selectedStory];if(g){g.children.forEach(o=>{if(o.name==='red paper lantern')o.rotation.z=Math.sin(clock.elapsedTime*1.7+o.position.z)*.035;if(o.name==='floating dark whistle')o.position.y=2.4+Math.sin(clock.elapsedTime*2)*.12;});}}
}
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);update(dt);renderer.render(scene,camera)}animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.7))});
